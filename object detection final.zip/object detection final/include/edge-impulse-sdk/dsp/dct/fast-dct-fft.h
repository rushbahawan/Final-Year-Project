#ifndef __FAST_DCT_FFT__H__
#define __FAST_DCT_FFT__H__

// This file intentinally left blank
// Function moved to numpy.hpp

#endif  //!__FAST-DCT-FFT__H__